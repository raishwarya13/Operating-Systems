/*
 Names: Aishwarya Ravishankar and Alina Suon
 Date: Feb 27th, 2019
 Project Description: The objective of this project is to demonstrate on how to use the linux system function fork() to develop a simple terminal. When the function is called the program executable will create a shell prompt while the user can enter either of thi commands.
 */

// this declares gnu
#define _GNU_SOURCE
// this is the header file for C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// this declares the length of the buffer
#define BUFFER_LEN 1024

// this initialzes the functions
int changeDir(char **args);
int exitprogram(void);
char *read_commands(void);


// while using the buffer it reads the commands
char *read_commands(void){
    int bufSize = BUFFER_LEN;
    // this makes it so theres memory in the buffer
    char *buffer = malloc(sizeof(char)*bufSize);
    // this checks to see if the memory was allocated
    if(!buffer){
        fprintf(stderr, "Buffer: allocation error\n");
        exit(EXIT_FAILURE);
    }
    int c;
    int length =0;
// this makes it so theres characters in the buffer
    while(1){
        c = getchar();
        //this checks to see if there is a end of line command
        if (c == EOF || c == '\n') {
            buffer[length] = '\0';
            return buffer;
        } else {
            buffer[length] = c;
        }
        length++;
        
// checks to see the size of the buffer
        if (length >= bufSize) {
            bufSize += BUFFER_LEN;
            buffer = realloc(buffer, bufSize);
            if (!buffer) {
                fprintf(stderr, "Buffer: allocation error\n");
                exit(EXIT_FAILURE);
            }
        }
    }
// the buffer is being returned
    return buffer;
}

int main(int argc, char** args){
//get the command line
    char *line;
// this sets the path to bin
    char* path= "/bin/";
// this is the full file path
    char progpath[20];
//this makes it see if the code can continue or exit
    int status = 1;
//checks the status of terminal
    while(status){
// this displays the current in the terminal
        char cwd[1024];
        getcwd(cwd, sizeof(cwd));
        printf("%s",cwd);
        printf("/>>> ");
        line = read_commands();
        if(strcmp(line, "exit")==0){
            status = exitprogram();
            continue;
        }
        char *token;
        token = strtok(line," ");
        int i=0;
        while(token!=NULL){
            args[i]=token;
            token = strtok(NULL," ");
            i++;
        }
// for the execvp sets the last value to NULL
        args[i]=NULL;
        argc=i;
        strcpy(progpath, path);
        strcat(progpath, args[0]);
// this deletes the newline just so it can make sure if it still exists
        for(i=0; i<strlen(progpath); i++){
            if(progpath[argc]=='\n'){
                progpath[argc]='\0';
            }
        }
//this checks to see if the command is cd
        if(strcmp(args[0],"cd") == 0){
            status = changeDir(args);
            continue;
        }
//this checks to see if the command was exist
        if(strcmp(args[0],"exit") == 0){
            status = exitprogram();
            continue;
        }
//this throws in an error expception 
        if(args[1]==NULL){
            fprintf(stderr, "Error: Command not found\n");
            continue;
        }
        else{
// this is the fork child
            int pid= fork();
//this is the procces child
            if(pid==0){
                if(execvp(progpath,args)==-1)
                    fprintf(stderr, "Error: could not execute command\n");
                exit(EXIT_FAILURE);
            }else{
                wait(NULL);
            }
        }
    }
}
// this chnages the directory
int changeDir(char **args){
    if(strcmp(args[0],"cd") == 0){
        if (args[1] == NULL) {
            fprintf(stderr, "cd: expected argument to \"cd [directory]\"\n");
        } else {
            if (chdir(args[1]) != 0) {
                perror("cd failure");
            }
        }
    }
    return 1;
}
int exitprogram(void){
    
    return 0;
    
}
