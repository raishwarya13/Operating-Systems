#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

using namespace std;

#include "../Utilities/Utils.h"
#include "../Utilities/Scanner.h"
#include "../Utilities/ScanLine.h"

#define NUM_THREADS 9
int matA[3][3];
int matB[3][3];
int matC[3][3];

void *matrix_mult(void *t) {
   long id;
   id = (long)t;
   long output_row,output_column,sum=0;
   output_row = id/3;
   output_column = id%3;
  
   for(int i=0;i<3;i++)
	sum+= matA[output_row][i] * matB[i][output_column];

   matC[output_row][output_column] = sum;
}

int main (int argc, char *argv[]) {
    string inFileName1 = "";
  string inFileName2 = "";
  string outFileName = "";
   ofstream outStream;
 
  Scanner scanner1;
  Scanner scanner2;
  Scanner out;  

  string element = "";
 
  Utils::CheckArgs(3, argc, argv, "infilename (first matrix) outfilename (second matrix)");
  inFileName1 = static_cast<string>(argv[1]);
  inFileName2 = static_cast<string>(argv[2]);
   outFileName = (static_cast<string>(argv[3]));

  scanner1.openFile(inFileName1);
  scanner2.openFile(inFileName2);  
  int i=0,j=0;
  while (scanner1.hasNext()) {

      element = scanner1.next();
      if(i<3){
	matA[j][i] = stoi(element);
	i++;
      }
      else{
	i=0;
	j++;
	matA[j][i] = stoi(element);
	i++;
      }   
  }
i=0,j=0;
   while (scanner2.hasNext()) {

      element = scanner2.next();
      if(i<3){
	matB[j][i] = stoi(element);
	i++;
      }
      else{
	i=0;
	j++;
	matB[j][i] = stoi(element);
	i++;
      }   
  }




pthread_t threads[NUM_THREADS];

for(i=0;i<NUM_THREADS;i++){
	pthread_create(&threads[i],NULL,matrix_mult,(void *)i);
}

for(i=0;i<NUM_THREADS;i++){
	pthread_join(threads[i],NULL);
}



outStream.open(outFileName);
for(i=0;i<3;i++){
	for(j=0;j<3;j++)
		outStream<<matC[i][j]<< " ";
	outStream<<endl;
}
outStream.close();  


  
  return 0;
}

